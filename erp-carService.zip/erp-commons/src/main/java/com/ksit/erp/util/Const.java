package com.ksit.erp.util;

/**
 * Created by houfalv on 2018/7/26.
 */
public class Const {

    public static final String CURRENT_EMPLOYEE = "current_employee";
    public static final String EMPLOYEE_NROMAL = "2";

}
